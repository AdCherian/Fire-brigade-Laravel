<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
 <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Sprzęt')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="flex mx-auto items-center justify-center shadow-lg mt-56 max-w-lg">
   <form method="POST" action="./<?php echo e($sprzet->id); ?>" class="w-full max-w-xl bg-white rounded-lg px-4 pt-2">
    <?php echo csrf_field(); ?>

      <div class="flex flex-wrap -mx-3 mb-6">
         <h2 class="px-4 pt-3 pb-2 text-gray-800 text-lg">Dodaj sprzęt</h2>
         <div class="w-full md:w-full px-3 mb-2 mt-2">
            <!-- <textarea class="bg-gray-100 rounded border border-gray-400 leading-normal resize-none w-full h-20 py-2 px-3 font-medium placeholder-gray-700 focus:outline-none focus:bg-white" name="body" placeholder='Type Your Comment' required></textarea> -->
            <label class="block text-gray-700 text-sm font-bold mt-2" for="nazwa">Nazwa</label>
            <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
            id="nazwa" name="nazwa" type="text" value="<?php echo e($sprzet->nazwaSprzetu); ?>" placeholder="Wpisz informacje">

            <label class="block text-gray-700 text-sm font-bold mt-2" for="ilosc">Ilość</label>
            <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
            id="ilosc" name="ilosc" type="number" value="<?php echo e($sprzet->iloscSprzetu); ?>" placeholder="Wpisz informacje">

            <label class="block text-gray-700 text-sm font-bold mt-2" for="data">Data przydatności</label>
            <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
            id="data" name="data" type="date" value="<?php echo e($sprzet->stopienZuzycia); ?>" placeholder="Wpisz informacje">

            
      
        </div>
         <div class="w-full md:w-full flex items-start md:w-full px-3">
            
            <div class="-mr-1">
               <input type='submit' class="bg-white text-gray-700 font-medium py-1 px-4 border border-gray-400 rounded-lg tracking-wide mr-1 hover:bg-gray-100" value='Dodaj sprzęt'>
            </div>
         </div>
      </form>
   </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /home/s44461/public_html/example-app/resources/views/edytujsprzetid.blade.php ENDPATH**/ ?>